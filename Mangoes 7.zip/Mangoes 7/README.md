myself, Sierra 7 iOS, bensound and pixabay.com for assets

# Project Title

Timmy Tuff Knuckles' whole juiceline was pressed by the Mango clan. Your purpose? Hunt, juice, and blend mangoes.

[Optional: drop in a screenshot or GIF of your game here so readers can see what the screen looks like when it opens.]

![screenshot](assets/screenshot.png)

## Description

What is this project? Describe the interactive experience: what kind of game/experience it is, what the player is trying to do, and what makes it interesting. (2 to 4 sentences.)

## How to Run

1. Make sure you have **Python 3.13** installed.
2. Install the dependencies:
   *For most of you, this is just `pip install pygame-ce`.*
3. Run the game:
   ```
   python main.py
   ```

## Controls

| Input | Action |
|-------|--------|
| Arrow keys / WASD | [e.g. move the player] |
| Spacebar | [e.g. jump / shoot] |
| Mouse | [e.g. aim / click to select] |
| Esc | [e.g. quit] |

## Features

- [ ] Screen opens to show the environment
- [ ] Elements drawn on the screen  [briefly: what is drawn]
- [ ] User-controlled elements [briefly: what the user controls]
- [ ] [Any extra features you're proud of]

## Dependencies

- Python 3.13
- pygame-ce
- [any other PyPI libraries - list them, or write "none beyond pygame"]

## Assets

List any images, sounds, fonts, or other files in the `Assets/` folder, and where each came from:

- `Assets/mango.png` - The mango is by me, and clipartmax.com for the knife
- `Assets/ngbarrel.png` - eagle.justrite.com/lab-pack-salvage-poly-drum-55-gallon-metal-lever-lock-2x2-bung-holes-yellow-1656mbg2 
- `Assets/crosshair.png` - procrosshairs.com, from donk
- `Assets/menu_screen.png` - Screenshot of Sierra 7 by SHD Digital

- `Assets/fortnite.mp3` - myinstants.com by Timchinium.exe
- `Assets/mi-bombo.mp3` - myinstants.com by nathaniel8254
- `Assets/pump-shotgun-fortnite-loud.mp3` - myinstants.com by harry443
- `Assets/half-life-crowbar.mp3` - myinstants.com by myinstantstelegrambot

## Starting Point (Class Code)

State which code from class you used as a starting point, as required by the guardrails:

- Started from `[14-pygame-screens]` - used for the menu screen to support my idea for a text-based exposition.

## AI Disclosure

Disclose code or ideas where AI was used, including the **model** and **line numbers / commits**. Per the rubric, copy-and-pasted AI code is discouraged and, if used, **pasted lines need your own explanation of what it does and why**

You could use the table below or just list using bullets.

**Model(s) used:** [e.g. Claude Opus 4.8, ChatGPT, etc.]

| Lines / Commit | What it does (in my own words) | Why I used it | AI vs. my own |
|----------------|--------------------------------|---------------|---------------|
| `main.py` lines [x-y] / commit [hash] | [explain the code] | [why] | [pasted / adapted / written by me with AI help] |

*(If no AI was used at all, write "No AI was used in this project." If AI was only used to learn concepts and no code was pasted, say that explicitly.)*

## Known Bugs / Limitations

- [anything that doesn't work perfectly]

## Possible Future Improvements

- [ideas you'd add with more time]

## Author

Joshua Gansner
